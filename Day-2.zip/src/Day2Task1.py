
name = input("Enter your name: ")
age = input("Enter your current age: ")
age = int(age)
new_age = age + 4
print(f"Hey {name}, you will be {new_age} years old in 2030!")